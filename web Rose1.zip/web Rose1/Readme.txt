Nom:Jacques
Prenom:Rose-guerchise
niveau d'etude:2eme annee 
Departement:Sc Informatiques
vacation:median A
Universite:Inuka